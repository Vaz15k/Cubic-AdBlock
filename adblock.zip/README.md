Hosts List:

The Ultimate Hosts Blacklist
https://github.com/Ultimate-Hosts-Blacklist/Ultimate.Hosts.Blacklist