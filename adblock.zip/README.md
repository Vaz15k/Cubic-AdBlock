Hosts List:

adaway.org
https://adaway.org/hosts.txt

github.com/StevenBlack/hosts
https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts

The Ultimate Hosts Blacklist
https://github.com/Ultimate-Hosts-Blacklist/Ultimate.Hosts.Blacklist