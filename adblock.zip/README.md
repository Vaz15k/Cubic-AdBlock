Hosts List:

adaway.org
https://adaway.org/hosts.txt

github.com/StevenBlack/hosts
https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts