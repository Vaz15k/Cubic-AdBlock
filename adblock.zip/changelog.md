## v1.5 - 23-11-20
	* Update hosts file
	* Fixed problem with not blocking ads

## v1.4 - 23-11-28
	* Updated Hosts file with UHB (The Ultimate Hosts Blacklist)
	
## v1.3 - 23-11-14
	* Update hosts file
	
## v1.2 - 23-11-08
	* Update hosts file

## v1.1 - 23-10-24
	* Update hosts file

### v1.0 - 23-10-11
	* First Release
